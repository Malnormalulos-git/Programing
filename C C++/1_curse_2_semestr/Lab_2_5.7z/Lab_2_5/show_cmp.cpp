#include "complex.h"
#include<iostream>
using namespace std;
void show_cmp(CMP com){
	cout << showpos << com.real << com.imag << "*i" << endl;
}
